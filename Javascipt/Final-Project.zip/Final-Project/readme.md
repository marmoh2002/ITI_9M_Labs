# Final Project

## Description
A JavaScript project demonstrating core javascript concepts.

![Project Screenshot](./screenshots/scr1.png)
![Project Screenshot](./screenshots/scr2.png)
![Project Screenshot](./screenshots/scr3.png)
![Project Screenshot](./screenshots/scr4.png)
![Project Screenshot](./screenshots/scr5.png)